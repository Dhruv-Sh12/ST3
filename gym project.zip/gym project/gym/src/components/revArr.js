const arr=[
    {id:1,
    review:"Amazing experience at Freak. Excellent personal training. Trainers who really care and go above and beyond to help you achieve your goals. Small and private gym that feels more personal. Highly recommended!"},
    {id:2,
        review:" has been awesome to me. Their trainers are exceptional, the overall vibe is great and I have had nothing but good experiences. I definitely recommend them to my friends and family. "},
        {id:3,
            review:" Amazing personal trainers and complete, clean gym. Would highly recommend!"},
            {id:4,
                review:"Hands down, best choice I’ve made training at . VERY friendly team who make me actually want to go train. I look forward to walking through the doors and always feel amazing when I leave"},
                {id:5,
                    review:"This is a fantastic gym!! All the trainers are super nice and take an interest in you no matter what fitness level you’re at. I really like how they give me tips and tricks to get the most out of every workout. I’ve been going for a little bit and am already seeing a big change in my energy levels and body. It’s great! I feel 10 years younger!"},
                    {id:6,
                        review:"My first experience with  and have not been disappointed! I train here about 4-5 times a week and find the consistent positive trainers, awesome music and participants who take class create a perfect workout environment. I love that they provide parking validation, towels for workouts, water and most importantly the same group of quality trainers are there to personally get to know you and push you in the right way. It’s a hard workout with happy people! And I am seeing results for sure."}

                        
                        
        
]
export default arr;