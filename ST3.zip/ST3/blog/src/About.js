import React from 'react';
import './main.css';
export default function About() {
  return (
    <div className='abtcont'>
     <p className='abt'>
     Hare Krishna to all
    Spiritual Charcha is a movement to spread glories of Lord Shri Krishna and his devotees.  New series, episodes are surely going to make you love the lord more. please join me in this movement to spread Krishna Prem all around.
    Jai Siya Ram
    You can visit our Youtube channel for amazing Spiritual Content by just clicking this <a href='https://www.youtube.com/channel/UCvOfZvK-1ikFuw-lMUZs_kQ'>link</a>
     </p>

     <div className="footer">
      <center>
      <a href="/"><i class="fa-brands fa-facebook fa-5x"></i></a>
      <a href="/"><i class="fa-brands fa-instagram fa-5x "></i></a>
      <a href="/"><i class="fa-brands fa-twitter fa-5x"></i></a>
      </center>
     

     </div>
    </div>
  );
}
