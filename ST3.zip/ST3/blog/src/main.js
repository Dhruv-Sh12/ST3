import React from "react";
import data from "./data";
import Cards from "./card";
import './App.css'
import './main.css';


const Amazon = () => {
  return (
    <section>
      {data.map((item) => (
        <Cards key={item.id} item={item}  />
      ))}
    </section>
  );
};

export default Amazon;