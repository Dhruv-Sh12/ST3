import React from 'react';

import './App.css';
import './main.css';
// import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Main from './main';
import Navbar from './Navbar';
import About from './About';
import Yt from './Yt';

function App() {
  return (
    <>
    
    <BrowserRouter>
    <Navbar/>
    <div className="body">

    <Routes>
    <Route path="/" element={<Main />}></Route>
    <Route path="about" element={<About />} ></Route>
    <Route path="yt" element={<Yt />} ></Route>



    </Routes>
    </div>
    </BrowserRouter>
   
   
   
    
    
    
    </>
  );
}

export default App;
