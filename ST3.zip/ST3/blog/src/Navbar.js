import React from 'react';
import './main.css'
import { Link } from 'react-router-dom';
export default function Navbar() {
  return (
    <div>
      <nav>
        <img src="https://th.bing.com/th/id/OIP.C9L1oensJydb2WIlSGvm2AAAAA?w=164&h=180&c=7&r=0&o=5&dpr=1.2&pid=1.7" alt="" />
        <h2>SpiritualBlogger.com</h2>
        <Link to="/"><i class="fa-solid fa-house fa-2x"></i></Link>
        <Link to="/about"><i class="fa-solid fa-user fa-2x"></i></Link>
        {/* <Link to="/yt"><i class="fa-brands fa-youtube fa-2x"></i></Link> */}
      </nav>
    </div>
  );
}

