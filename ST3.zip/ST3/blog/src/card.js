import React from "react";
import './main.css';
const Cards = ({ item}) => {
  const { title, desc, image} = item;
  return (
    <div className="cards">
      <div className="image_box">
        <center><img src={image} alt="" /></center>
      </div>
      <div className="details">
        <h2>{title}</h2>
        <p>{desc}</p>
        
        
      </div>
    </div>
  );
};

export default Cards;